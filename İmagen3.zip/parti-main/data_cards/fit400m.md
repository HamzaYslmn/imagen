FIT400M data card in [pdf](fit400m_data_card.pdf).
