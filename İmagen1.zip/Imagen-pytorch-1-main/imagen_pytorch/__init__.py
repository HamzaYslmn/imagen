"""
A codebase for performing model inference with a text-conditional diffusion model.
"""
